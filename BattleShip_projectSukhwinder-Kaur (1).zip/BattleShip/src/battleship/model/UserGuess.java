package battleship.model;

import java.util.ArrayList;
import java.util.Scanner;

import battleship.Main;

public class UserGuess {
	public static int UserInput(String[][][] userBoard,String[][][] boardAI,ArrayList<String> userShips,ArrayList<String> aiShips,ArrayList<Move> moveHistAI,int hit,int type){
	    boolean gotXCoord=false;
	    boolean gotYCoord=false;
	    boolean cordsSet=false;
	    boolean done=false;
	    int xCoord=0;
	    int yCoord=0;
	    Main.space();
	    while(!cordsSet){
	      gotXCoord=false;
	      gotYCoord=false;
	      if(hit==0){
	        System.out.print("\tYou missed\n");
	      }
	      else if(hit==1){
	        System.out.print("\tYou hit a ship\n");
	      }
	      else if(hit==2){
	        System.out.print("\tYou sunk a ship\n");
	      }
	      hit=-1;
	      while(!gotXCoord){
	    	  if(type==0)
	    	  {
	        selectScreen(userBoard,boardAI,0);
	    	  }
	    	  else {
	    		  selectScreen(userBoard, boardAI, 1);  
	    		  }
	        System.out.print("\n(");
	        xCoord= getCoord();
	        if(xCoord!=-1){
	          gotXCoord=true;
	        }
	      }
	      
	      Main.space();
	      while(!gotYCoord){
	    	  if(type==0)
	    	  {
	        selectScreen(userBoard,boardAI,0);
	    	  }
	    	  else {
	    		  selectScreen(userBoard, boardAI, 1);  
	    		  }

	       System.out.print("If you would like to start your point selection over enter \"CANCEL\" ");
	        System.out.print("\n("+xCoord+",");
	        yCoord= getCoord();
	        
	        if(yCoord>0){
	          gotYCoord=true;
	          if((boardAI[0][Main.gTOaY(yCoord)][Main.gTOaX(xCoord)]==null)||!boardAI[0][Main.gTOaY(yCoord)][Main.gTOaX(xCoord)].equals("ged")){
	            cordsSet=true;
	            done=true;
	            gotYCoord=true;
	          }
	          else{
	            yCoord=-3;
	          }
	        }
	        Main.space();
	        if(yCoord==-3){
	          System.out.print("\tYou already guessed that point\n");
	        }
	        else if(yCoord<0){
	          System.out.print("\tThat was not a valid coordinate.\n");
	        }
	        if(yCoord<=-3){
	          done=false;
	          gotYCoord=true;
	        }
	      }
	      if(!done){
	        gotXCoord=false;
	        gotYCoord=false;
	        cordsSet=false;
	        xCoord=0;
	        yCoord=0;
	      }
	    }
	    return guessResults(boardAI,aiShips,moveHistAI,xCoord,yCoord,type);
	  }
	  
	  public static int guessResults(String[][][] boardAI,ArrayList<String> shipList,ArrayList<Move> moveHist,int x,int y, int type){
	    x=Main.gTOaX(x);
	    y=Main.gTOaY(y);
	    String boardPlace=boardAI[0][y][x];
	    int hit;
	    if (type==0) {
	    	boardAI[0][y][x]="ged";	
		}
	    if(boardPlace==null){
	      hit=0;
	      boardAI[1][y][x]="O";
	    }
	    else{
	      if(shipContain(boardAI,boardPlace)){
	        hit=1;//hit ship not sink
	        boardAI[1][y][x]="X";
	      }
	      else{
	        String symbolShip="";
	        hit=2;
	        int length=0;
	        if (boardPlace.equals("a")){
	          symbolShip="@"; //carrier
	        }
	        else if(boardPlace.equals("s")){
	          symbolShip="$"; //submarine
	        }
	        else if(boardPlace.equals("d")){
	          symbolShip="%"; //destroyer
	        }
	        else if(boardPlace.equals("p")){
		          symbolShip="*"; //patrol boat
		        }
	        for(int r = 0;r<10;r++){
	          for(int c = 0; c<10;c++){
	            try{
	              if(boardAI[2][r][c].equals(boardPlace)){
	                boardAI[1][r][c] = symbolShip;
	              }
	            }
	            catch(Exception e){}
	          }
	        }
	        shipList.remove(shipList.indexOf(boardPlace));
	      }
	    }
	    return hit;
	  }
	  
	  
	  public static int getCoord(){
	    Scanner coordInput = new Scanner(System.in);
	    String stringCoord = coordInput.nextLine();
	    try{
	      int newCoord = Integer.parseInt(stringCoord);
	      if(newCoord>10||newCoord<1){
	        throw new Exception();
	      }
	      return newCoord;
	    }
	    catch(Exception e){
	     Main.space();
	      System.out.print("\tThat was not a valid number.\n");
	      stringCoord=stringCoord.toUpperCase();
	      if(stringCoord.equals("CANCEL")){
	        return -2;
	      }
	    }
	    return -1;
	  }
	  
	  public static boolean shipContain(String[][][] boardAI,String boardPlace){
	    for(int r = 0;r<10;r++){
	      for(int c = 0; c<10;c++){
	        try{
	          if(boardAI[0][r][c].equals(boardPlace)){
	            return true;
	          }
	        }
	        catch(Exception e){}
	      }
	    }
	    return false;
	  }
	  
	  public static void selectScreen(String[][][] user1Board,String[][][] boardAI,int type){
	    System.out.print("\nTime to make your move.....\n\nYour board\n");
	    Main.printBoard(user1Board,0);
		if(type==0)
	    {
	    System.out.print("\n\nPlayer2 Board\n");
	    Main.printBoard(boardAI,0);
	    }
		else {
	    System.out.print("\n\nComputers Board\n");
	    Main.printBoard(boardAI,1);
		}
	    System.out.print("\n\n\tWhat position would you like to guess?\n");
	  }
}
