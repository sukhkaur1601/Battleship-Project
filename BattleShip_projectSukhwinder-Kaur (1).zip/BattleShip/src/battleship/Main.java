package battleship;

import java.util.ArrayList;
import java.util.Scanner;

import battleship.model.AI;
import battleship.model.Move;
import battleship.model.UserGuess;
import battleship.view.CompInputShips;
import battleship.view.UserInputShips;

public class Main {
	public static void main(String[] args) {
	    
	    //creates multiple boards
	    
	    String[][][]user1Board = new String[3][10][10];
	    String[][][]user2Board = new String[3][10][10];
	    String[][][]boardAI = new String[3][10][10];
	    
	    /*
	    4 aircraft carrier  - a
	    3 submarine         - s
	    3 destroyer         - d
	    2 patrol boat       - p
	    */
	    
	    //creates history of moves made by user and the AI
	    ArrayList<Move> moveHistAI= new ArrayList<Move>();
	    ArrayList<String> users1Ships= new ArrayList<String>();
	    ArrayList<String> users2Ships= new ArrayList<String>();
	    ArrayList<String> aiShips= new ArrayList<String>();
	    
	    
	    
	    Scanner enter = new Scanner(System.in);
	    space(); 
	    System.out.println("\n\n\t Welcome to battleship \n\t\t");
	    System.out.println("\n\n 1. Play with Computer");
	    System.out.println("\n 2. Play with Friend");
	    Scanner ch=new Scanner(System.in);

	    int choice=ch.nextInt();
	    switch (choice) {
		case 1:
			intFillBoard(user1Board,0);
		    intFillBoard(boardAI,1);
		    shipLeftFill(users1Ships);
		    shipLeftFill(aiShips);
	    System.out.print("\n\n\n\n\n\tThis is your battleship board. Let's place your ships.\n\n");
	    printBoard(user1Board,0);
	    System.out.print("\n\nPRESS ENTER TO PLAY\n");
	    String wait = enter.nextLine();
	    
	    //hide ships in hiddenAI board
	    //hides user ships
	    
	    CompInputShips.autoFill(boardAI);
	    UserInputShips.userFill(user1Board);
	    int hit=-1;
	    int type=1;
	    boolean gameWon=false;
	    
	    for(int r = 0;r<10;r++){
	      for(int c = 0; c<10;c++){
	        boardAI[2][r][c]=boardAI[0][r][c];
	        user1Board[2][r][c]=user1Board[1][r][c];
	      }
	    }
	    
	    while(!gameWon){
	      hit=UserGuess.UserInput(user1Board,boardAI,users1Ships,aiShips,moveHistAI,hit,type);
	      if(aiShips.size()==0){
	        gameWon= true;
	      }
	      if(!gameWon){
	        AI.aiMove(user1Board,boardAI,users1Ships,aiShips,moveHistAI);
	        if(users1Ships.size()==0){
	          gameWon= true;
	        }
	      }
	    }
	    break ;
		case 2:
			intFillBoard(user1Board,0);
		    intFillBoard(user2Board,0);
			shipLeftFill(users1Ships);
		    shipLeftFill(users2Ships);
			System.out.print("\n\n\n\n\n\tPlayer1 battleship board. Let's place your ships.\n\n");
		    printBoard(user1Board,0);
		    System.out.print("\n\nPRESS ENTER TO PLAY\n");
		    String wait1 = enter.nextLine();
		    UserInputShips.userFill(user1Board);
		    System.out.print("\n\n\n\n\n\tPlayer2 battleship board. Let's place your ships.\n\n");
		    printBoard(user2Board,0);
		    System.out.print("\n\nPRESS ENTER TO PLAY\n");
		    String wait2 = enter.nextLine();
		    UserInputShips.userFill(user2Board);
		    int hit1=-1;
		    int hit2=-1;
		    boolean gameWon1=false;
		    
		    for(int r = 0;r<10;r++){
		      for(int c = 0; c<10;c++){
		        user1Board[2][r][c]=user1Board[1][r][c];
		        user2Board[2][r][c]=user2Board[1][r][c];
		      }
		    }
		    
		    while(!gameWon1){
		      hit1=UserGuess.UserInput(user1Board,user2Board,users1Ships,users2Ships,moveHistAI,hit1,0);
		      if(users2Ships.size()==0){
		        gameWon= true;
		      }
		      if(!gameWon1){
		    	  hit2=UserGuess.UserInput(user1Board,user2Board,users1Ships,users2Ships,moveHistAI,hit2,1);
			        if(users1Ships.size()==0){
			          gameWon= true;
			        }
		    }
		    }
		    break;
		    default:
		    	System.out.println("Please choose valid option: ");

			    choice=ch.nextInt();
		    	break;
	    }
	    
	  }
	  
	  
	  //Fills board with "-" for ships to be placed on 
	  public static void intFillBoard(String[][][] grid, int e){
	    for(int r = 0;r<10;r++){
	      for(int c = 0; c<10;c++){
	        grid [e][r][c] = "-";
	      }
	    }
	  }
	  
	  //Prints coordinates on the side of the board
	  public static void printBoard(String[][][] grid, int a){
	    for(int r = 0;r<10;r++){
	      System.out.print(10-r +"   ");
	      if(r!=0){
	        System.out.print(" ");
	      }
	      for(int c = 0; c<10;c++){
	        System.out.print(grid[a][r][c] + " ");
	      }
	      System.out.print("\n");
	    }
	    System.out.print("\n     1 2 3 4 5 6 7 8 9 10");
	  }
	  
	  //Method for spacing screen out 
	  public static void space(){
	    for (int i=1;i<=54;i++){
	      System.out.print("\n");
	    }
	  }
	  //fills ship list 
	  public static void shipLeftFill(ArrayList<String> list){
	    list.add("a");
	    list.add("s");
	    list.add("d");
	    list.add("p");
	  }
	  
	  //Returns coordinates of grid since indexes are +1
	  public static int gTOaX(int graphX){
	    return graphX-1;
	  }
	  public static int gTOaY(int graphY){
	    return 10-graphY;
	  }
}
